﻿using System;
using System.Collections.Generic;
using SpaceCraft;
using UnityEngine;

namespace EpochNeural
{
    // FIX: Forced explicit public visibility modifier so other scripts see it
    public static class EpochDrillManager
    {
        private static readonly Dictionary<string, int> _activeDrillRegistry = new Dictionary<string, int>();

        public static bool TryRegisterDrill(string sectorGroupId, int worldObjectId)
        {
            if (string.IsNullOrEmpty(sectorGroupId)) return false;

            if (_activeDrillRegistry.ContainsKey(sectorGroupId))
            {
                Plugin.Logger?.LogWarning($"[Epoch Network] Sector Group [{sectorGroupId}] is occupied.");
                return false;
            }

            _activeDrillRegistry[sectorGroupId] = worldObjectId;
            Plugin.Logger?.LogInfo($"[Epoch Network] Drill [{worldObjectId}] linked to Group [{sectorGroupId}].");

            RefreshNetworkTelemetry();
            return true;
        }

        public static void UnregisterDrill(int worldObjectId)
        {
            string targetKey = null;
            foreach (var pair in _activeDrillRegistry)
            {
                if (pair.Value == worldObjectId) { targetKey = pair.Key; break; }
            }

            if (targetKey != null)
            {
                _activeDrillRegistry.Remove(targetKey);
                RefreshNetworkTelemetry();
            }
        }

        public static bool IsBiomeOccupied(string sectorGroupId)
        {
            if (string.IsNullOrEmpty(sectorGroupId)) return false;
            return _activeDrillRegistry.ContainsKey(sectorGroupId);
        }

        public static int GetActiveDrillsCount()
        {
            return _activeDrillRegistry.Count;
        }

        public static void RefreshNetworkTelemetry()
        {
            if (EpochDevHud.Instance != null)
            {
                EpochDevHud.Instance.UpdateHud(
                    EpochVacuumSystem.IsInitialized(),
                    EpochVacuumSystem.GetHudObjects(),
                    EpochHubLogistics.GetTotalItemCount()
                );
            }
        }

        public static void ResetNetwork()
        {
            _activeDrillRegistry.Clear();
            RefreshNetworkTelemetry();
        }
    }
}
