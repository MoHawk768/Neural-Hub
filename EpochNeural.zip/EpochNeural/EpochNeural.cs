﻿using HarmonyLib;
using SpaceCraft;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace EpochNeural
{
    [HarmonyPatch(typeof(StaticDataHandler), "LoadStaticData")]
    internal static class EpochNeural
    {
        internal const int HubInventorySize = 240;
        internal const string HubId = "Epoch_Hub";
        internal const string DrillId = "Epoch_Node_Drill";

        // ============================================================
        // TIER SYSTEM DATA
        // ============================================================
        public class HubTierData
        {
            public int Tier { get; set; }
            public string Name { get; set; }
            public int Budget { get; set; }
            public int StackCap { get; set; }
            public double UnlockTi { get; set; }
            public string StageName { get; set; }
        }

        public static readonly List<HubTierData> HubTiers = new List<HubTierData>
        {
            new HubTierData { Tier = 1, Name = "Epoch Hub", Budget = 50, StackCap = 25, UnlockTi = 0, StageName = "Barren" },
            new HubTierData { Tier = 2, Name = "Neural Mesh", Budget = 100, StackCap = 100, UnlockTi = 350000, StageName = "Clouds" },
            new HubTierData { Tier = 3, Name = "Synaptic Drive", Budget = 150, StackCap = 200, UnlockTi = 3000000, StageName = "Liquid Water" },
            new HubTierData { Tier = 4, Name = "Quantum Core", Budget = 200, StackCap = 350, UnlockTi = 700000000, StageName = "Flora" },
            new HubTierData { Tier = 5, Name = "Epoch Singularity", Budget = 250, StackCap = 500, UnlockTi = 120000000000, StageName = "Fish" }
        };

        private static int _currentTier = 1;
        private static int _hubWorldObjectId = -1;

        // ============================================================
        // RELOCATION STATE
        // ============================================================
        public static bool IsRelocating { get; set; } = false;
        public static bool IsRecovering { get; set; } = false;
        public static float RecoveryPercentage { get; set; } = 0f;
        public static int CurrentRecoveryBudget { get; set; } = 50;

        public static int CurrentTier => _currentTier;
        public static HubTierData CurrentTierData => GetTierData(_currentTier);
        public static int HubWorldObjectId => _hubWorldObjectId;

        // ============================================================
        // HUB RESTRICTION - 1 PER PLANET
        // ============================================================
        private static int _activeHubId = -1;
        private const string HubPlacementMessage = "EPOCH: A Hub already exists on this planet!";

        private static readonly FieldInfo GroupBackingIdField =
            typeof(Group).GetField("<id>k__BackingField", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

        private static readonly FieldInfo GroupAssociatedGameObjectField =
            typeof(Group).GetField("_associatedGameObject", BindingFlags.Instance | BindingFlags.NonPublic);

        private static readonly FieldInfo LocalizationDictionaryField =
            typeof(Localization).GetField("localizationDictionary", BindingFlags.Static | BindingFlags.NonPublic);

        internal static bool IsInitialized;
        internal static Inventory EpochHubInventory;
        internal static Inventory PlayerInventory;
        private static bool _hasInitialized = false;

        // ============================================================
        // ITEMS TO HIDE - Used by Harmony patches
        // ============================================================

        internal static readonly HashSet<string> ItemsToHide = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            // ============================================
            // ALL CONTAINERS / STORAGE
            // ============================================
            "Container1",
            "Container2",
            "Container3",
            "StorageCrate",
            "LockerStorage",
            "LockerStorageT2",
            "TrashCan",
            "Countertop1",
            "Countertop2",
            "Fridge",
            "SafeVault",
            "GoldenContainer",
            "StarformContainer",
            "ContainerAqualis",
            "ContainerGoldenAqualis",
            "ContainerToxic1",
            "BlueprintContainer",
            "BlueprintContainer3",
            "DebrisContainer",
            "ProceduralWreckContainer1",
            "ProceduralWreckContainer2",

            // ============================================
            // ALL ORE EXTRACTORS
            // ============================================
            "OreExtractor1",
            "OreExtractor2",
            "OreExtractor3",
            "OreExtractorT2",
            "OreExtractorT3",

            // ============================================
            // ALL DRONES
            // ============================================
            "DroneStation",
            "Drone",
            "DroneT2",
            "RocketDrones",
            "RocketDrones1",
            "RocketDrones2",
            "RocketDrones3"
        };

        public static HubTierData GetTierData(int tier)
        {
            if (tier < 1 || tier > HubTiers.Count)
                return HubTiers[0];
            return HubTiers[tier - 1];
        }

        public static HubTierData GetNextTierData()
        {
            if (_currentTier >= HubTiers.Count)
                return null;
            return HubTiers[_currentTier];
        }

        public static bool IsAtMaxTier()
        {
            return _currentTier >= HubTiers.Count;
        }

        public static void SetHubWorldObjectId(int id)
        {
            _hubWorldObjectId = id;
        }

        public static int GetEffectiveBudget()
        {
            if (IsRecovering)
            {
                return CurrentRecoveryBudget;
            }
            return CurrentTierData?.Budget ?? 50;
        }

        public static int GetEffectiveStackCap()
        {
            if (IsRecovering)
            {
                int tier = 1;
                if (CurrentRecoveryBudget >= 250) tier = 5;
                else if (CurrentRecoveryBudget >= 200) tier = 4;
                else if (CurrentRecoveryBudget >= 150) tier = 3;
                else if (CurrentRecoveryBudget >= 100) tier = 2;
                else tier = 1;

                var tierData = GetTierData(tier);
                return tierData?.StackCap ?? 25;
            }
            return CurrentTierData?.StackCap ?? 25;
        }

        public static string GetRecoveryStatus()
        {
            if (IsRelocating)
            {
                return EpochRelocation.Instance?.GetStatusText() ?? "RELOCATING...";
            }
            if (IsRecovering)
            {
                return EpochRelocation.Instance?.GetStatusText() ?? "RECOVERING...";
            }
            return null;
        }

        [HarmonyPostfix]
        private static void Postfix()
        {
            if (_hasInitialized)
            {
                Plugin.Logger.LogInfo("[Epoch] Already initialized, skipping.");
                return;
            }
            _hasInitialized = true;

            try
            {
                Plugin.Logger.LogInfo("[Epoch] Initializing Central Core...");

                RegisterEpochHub();
                RegisterEpochDrill();
                RegisterLocalization();

                Plugin.Logger.LogInfo($"[Epoch] Will hide {ItemsToHide.Count} vanilla items from menus.");

                var relocation = EpochRelocation.Instance;
                if (relocation != null)
                {
                    Plugin.Logger.LogInfo("[Epoch] Relocation system initialized.");
                }

                IsInitialized = true;
            }
            catch (Exception ex)
            {
                Plugin.Logger.LogError($"[Epoch] System initialization failure: {ex}");
            }
        }

        // ============================================================
        // HARMONY PATCH: Hide items from CONSTRUCTION menu
        // ============================================================

        [HarmonyPatch(typeof(UiWindowConstruction), "CreateGrid")]
        [HarmonyPrefix]
        private static bool PrefixCreateGrid(UiWindowConstruction __instance)
        {
            try
            {
                var gridField = typeof(UiWindowConstruction).GetField("grid", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                var constructionGroupPrefabField = typeof(UiWindowConstruction).GetField("constructionGroupPrefab", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                var groupListDisplayersField = typeof(UiWindowConstruction).GetField("_groupListDisplayers", BindingFlags.Instance | BindingFlags.NonPublic);

                if (gridField == null || constructionGroupPrefabField == null || groupListDisplayersField == null)
                    return true;

                GridLayoutGroup grid = gridField.GetValue(__instance) as GridLayoutGroup;
                GameObject constructionGroupPrefab = constructionGroupPrefabField.GetValue(__instance) as GameObject;
                var groupListDisplayers = groupListDisplayersField.GetValue(__instance) as List<GroupListGridDisplayer>;

                if (grid == null || constructionGroupPrefab == null || groupListDisplayers == null)
                    return true;

                var currentCategoryField = typeof(UiWindowConstruction).GetField("_currentCategory", BindingFlags.Instance | BindingFlags.NonPublic);
                DataConfig.GroupCategory selectedGroupCategory = DataConfig.GroupCategory.Null;
                if (currentCategoryField != null)
                {
                    selectedGroupCategory = (DataConfig.GroupCategory)currentCategoryField.GetValue(__instance);
                }

                var hasCleanChipField = typeof(UiWindowConstruction).GetField("_hasCleanChip", BindingFlags.Instance | BindingFlags.NonPublic);
                bool hasCleanChip = false;
                if (hasCleanChipField != null)
                {
                    hasCleanChip = (bool)hasCleanChipField.GetValue(__instance);
                }

                bool hideLowerTiers = hasCleanChip;
                var uiButtonToggleTiersField = typeof(UiWindowConstruction).GetField("uiButtonToggleTiers", BindingFlags.Instance | BindingFlags.Public);
                if (uiButtonToggleTiersField != null)
                {
                    var toggle = uiButtonToggleTiersField.GetValue(__instance) as UiButtonBool;
                    if (toggle != null)
                    {
                        hideLowerTiers = hasCleanChip && toggle.GetStatus();
                    }
                }

                GameObjects.DestroyAllChildren(grid.gameObject);

                List<GroupConstructible> groupsConstructible = GroupsHandler.GetGroupsConstructible();
                GroupInfosDisplayerBlocksSwitches blocksSwitches = new GroupInfosDisplayerBlocksSwitches
                {
                    showDescription = true,
                    showRecipe = true,
                    showUnits = true,
                    showMultipliers = true,
                    showTerraStageRequirementsWithUnits = true
                };

                bool everythingUnlocked = Managers.GetManager<GameSettingsHandler>().GetCurrentGameSettings().GetEverythingUnlocked();

                foreach (GroupListGridDisplayer groupListDisplayer in groupListDisplayers)
                {
                    if (groupListDisplayer == null) continue;

                    GridLayoutGroup component = groupListDisplayer.GetComponent<GridLayoutGroup>();
                    groupListDisplayer.HideTitle();

                    foreach (GroupConstructible item in groupsConstructible)
                    {
                        if (item == null) continue;

                        string itemId = item.GetId();

                        // SKIP items we want to HIDE
                        if (ItemsToHide.Contains(itemId))
                            continue;

                        if (hideLowerTiers && item.GetNextTierGroup() != null && item.GetNextTierGroup().GetUnlockingInfos().GetIsUnlocked())
                            continue;

                        if (item.GetGroupCategory() == groupListDisplayer.groupCategory &&
                            (selectedGroupCategory == DataConfig.GroupCategory.Null || item.GetGroupCategory() == selectedGroupCategory) &&
                            (item.GetUnlockingInfos().GetIsUnlocked(checkIfAvailableOnCurrentPlanet: true) || everythingUnlocked || item.GetIsGloballyUnlocked()) &&
                            (!everythingUnlocked || item.GetUnlockingInfos().GetIsAvailableOnCurrentPlanet()))
                        {
                            groupListDisplayer.SetTitle();

                            GameObject gameObject = UnityEngine.Object.Instantiate(constructionGroupPrefab);
                            if (gameObject == null) continue;

                            var image = gameObject.transform.GetChild(0)?.GetComponent<Image>();
                            if (image != null)
                            {
                                image.sprite = item.GetImage();
                            }

                            gameObject.name = item.id;

                            gameObject.AddComponent<EventHoverShowGroup>().SetHoverGroupEvent(item, blocksSwitches);
                            gameObject.AddComponent<EventHoverIncrease>().SetHoverGroupEvent();
                            gameObject.AddComponent<EventFixScrollRect>();

                            // Create callback data for this item
                            EventTriggerCallbackData callbackData = new EventTriggerCallbackData(item);

                            // Add EventGamepadAction with proper callbacks
                            EventGamepadAction gamepadAction = gameObject.AddComponent<EventGamepadAction>();
                            gamepadAction.SetEventGamepadAction(
                                (EventTriggerCallbackData data) =>
                                {
                                    var method = __instance.GetType().GetMethod("OnImageClickedViaGamepad", BindingFlags.Instance | BindingFlags.NonPublic);
                                    if (method != null) method.Invoke(__instance, new object[] { data });
                                },
                                callbackData,
                                null,
                                null,
                                (EventTriggerCallbackData data) =>
                                {
                                    var method = __instance.GetType().GetMethod("OnImagePinnedViaGamepad", BindingFlags.Instance | BindingFlags.NonPublic);
                                    if (method != null) method.Invoke(__instance, new object[] { data });
                                }
                            );

                            Button button = gameObject.GetComponent<Button>();
                            if (button != null)
                            {
                                ColorBlock colors = button.colors;
                                colors.selectedColor = new Color(colors.selectedColor.r, colors.selectedColor.g, colors.selectedColor.b, 0.25f);
                                colors.highlightedColor = colors.selectedColor;
                                colors.normalColor = default(Color);
                                button.colors = colors;
                            }

                            // Add pointer click event with proper callback
                            EventsHelpers.AddTriggerEvent(
                                gameObject,
                                EventTriggerType.PointerClick,
                                (EventTriggerCallbackData data) =>
                                {
                                    var method = __instance.GetType().GetMethod("OnImageClicked", BindingFlags.Instance | BindingFlags.NonPublic);
                                    if (method != null) method.Invoke(__instance, new object[] { data });
                                },
                                callbackData
                            );

                            gameObject.transform.SetParent(component.transform);
                            gameObject.SetActive(true);
                            gameObject.transform.localScale = constructionGroupPrefab.transform.localScale;

                            if (component.transform.childCount == 1)
                            {
                                Managers.GetManager<WindowsGamepadHandler>().SelectForController(gameObject, true, Managers.GetManager<CanvasPinedRecipes>().GetIsPinPossible());
                            }
                        }
                    }
                }

                var currentCategoryField2 = typeof(UiWindowConstruction).GetField("_currentCategory", BindingFlags.Instance | BindingFlags.NonPublic);
                if (currentCategoryField2 != null)
                {
                    currentCategoryField2.SetValue(__instance, selectedGroupCategory);
                }

                var constructionCategoryBlocksField = typeof(UiWindowConstruction).GetField("_constructionCategoryBlocks", BindingFlags.Instance | BindingFlags.NonPublic);
                if (constructionCategoryBlocksField != null)
                {
                    var blocks = constructionCategoryBlocksField.GetValue(__instance) as List<UiConstructionCategoryBlock>;
                    if (blocks != null)
                    {
                        foreach (var block in blocks)
                        {
                            if (block != null)
                            {
                                block.SetSelected(block.groupCategory == selectedGroupCategory);
                            }
                        }
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                Plugin.Logger.LogError($"[Epoch] Error in PrefixCreateGrid: {ex.Message}");
                return true;
            }
        }

        // ============================================================
        // HARMONY PATCH: Hide items from CRAFTING menu
        // ============================================================

        [HarmonyPatch(typeof(UiWindowCraft), "CreateGrid")]
        [HarmonyPrefix]
        private static bool PrefixCreateCraftGrid(UiWindowCraft __instance)
        {
            try
            {
                var gridField = typeof(UiWindowCraft).GetField("grid", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (gridField == null) return true;

                GridLayoutGroup grid = gridField.GetValue(__instance) as GridLayoutGroup;
                if (grid == null) return true;

                GameObjects.DestroyAllChildren(grid.gameObject);

                List<GroupItem> groupsItem = GroupsHandler.GetGroupsItem();
                GroupInfosDisplayerBlocksSwitches blocksSwitches = new GroupInfosDisplayerBlocksSwitches
                {
                    showDescription = true,
                    showRecipe = true,
                    showMultipliers = true,
                    showInfos = true,
                    showIngredientsFromEquipment = true
                };

                bool everythingUnlocked = Managers.GetManager<GameSettingsHandler>().GetCurrentGameSettings().GetEverythingUnlocked();

                var sourceCrafterField = typeof(UiWindowCraft).GetField("sourceCrafter", BindingFlags.Instance | BindingFlags.NonPublic);
                ActionCrafter sourceCrafter = null;
                if (sourceCrafterField != null)
                {
                    sourceCrafter = sourceCrafterField.GetValue(__instance) as ActionCrafter;
                }

                foreach (GroupItem item in groupsItem)
                {
                    if (item == null) continue;

                    string itemId = item.GetId();

                    if (ItemsToHide.Contains(itemId))
                        continue;

                    bool canBeCrafted = true;
                    if (sourceCrafter != null)
                    {
                        canBeCrafted = item.CanBeCraftedIn(sourceCrafter.GetCrafterIdentifier());
                    }

                    if ((item.GetUnlockingInfos().GetIsUnlocked(checkIfAvailableOnCurrentPlanet: true) || everythingUnlocked || item.GetIsGloballyUnlocked()) &&
                        (!everythingUnlocked || item.GetUnlockingInfos().GetIsAvailableOnCurrentPlanet()) &&
                        (!item.GetHideInCrafter() || everythingUnlocked) &&
                        canBeCrafted)
                    {
                        GameObject gameObject = new GameObject();
                        Image image = gameObject.AddComponent<Image>();
                        image.sprite = item.GetImage();

                        gameObject.AddComponent<EventHoverShowGroup>().SetHoverGroupEvent(item, blocksSwitches);
                        gameObject.AddComponent<EventHoverIncrease>().SetHoverGroupEvent();

                        // Create callback data for this item
                        EventTriggerCallbackData callbackData = new EventTriggerCallbackData(item);

                        // Add pointer click event with proper callback
                        EventsHelpers.AddTriggerEvent(
                            gameObject,
                            EventTriggerType.PointerClick,
                            (EventTriggerCallbackData data) =>
                            {
                                var method = __instance.GetType().GetMethod("OnImageClicked", BindingFlags.Instance | BindingFlags.NonPublic);
                                if (method != null) method.Invoke(__instance, new object[] { data });
                            },
                            callbackData
                        );

                        // Add EventGamepadAction with proper callbacks
                        EventGamepadAction gamepadAction = gameObject.AddComponent<EventGamepadAction>();
                        gamepadAction.SetEventGamepadAction(
                            (EventTriggerCallbackData data) =>
                            {
                                var method = __instance.GetType().GetMethod("OnImageClickedViaGamepad", BindingFlags.Instance | BindingFlags.NonPublic);
                                if (method != null) method.Invoke(__instance, new object[] { data });
                            },
                            callbackData,
                            null,
                            null,
                            (EventTriggerCallbackData data) =>
                            {
                                var method = __instance.GetType().GetMethod("OnImagePinnedViaGamepad", BindingFlags.Instance | BindingFlags.NonPublic);
                                if (method != null) method.Invoke(__instance, new object[] { data });
                            }
                        );

                        gameObject.transform.SetParent(grid.transform);
                        image.GetComponent<RectTransform>().localScale = new Vector3(1f, 1f, 1f);
                        gameObject.SetActive(true);

                        if (grid.transform.childCount == 1)
                        {
                            Managers.GetManager<WindowsGamepadHandler>().SelectForController(gameObject, false, Managers.GetManager<CanvasPinedRecipes>().GetIsPinPossible());
                        }
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                Plugin.Logger.LogError($"[Epoch] Error in PrefixCreateCraftGrid: {ex.Message}");
                return true;
            }
        }

        // ============================================================
        // HARMONY PATCH: Hide items from BLUEPRINTS menu
        // ============================================================

        [HarmonyPatch(typeof(UiWindowBlueprints), "SetSpecificChipsData")]
        [HarmonyPrefix]
        private static bool PrefixSetSpecificChipsData(UiWindowBlueprints __instance)
        {
            try
            {
                var playerInventoryField = typeof(UiWindowBlueprints).GetField("playerInventory", BindingFlags.Instance | BindingFlags.NonPublic);
                if (playerInventoryField == null) return true;

                Inventory playerInventory = playerInventoryField.GetValue(__instance) as Inventory;
                if (playerInventory == null) return true;

                var chipsField = typeof(UiWindowBlueprints).GetField("chipsInInventory", BindingFlags.Instance | BindingFlags.NonPublic);
                if (chipsField == null) return true;

                var chipsInInventory = new List<WorldObject>();

                var groupBlueprintField = typeof(UiWindowBlueprints).GetField("groupBlueprint", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                GroupData groupBlueprint = null;
                if (groupBlueprintField != null)
                {
                    groupBlueprint = groupBlueprintField.GetValue(__instance) as GroupData;
                }

                foreach (WorldObject insideWorldObject in playerInventory.GetInsideWorldObjects())
                {
                    if (insideWorldObject == null) continue;
                    if (insideWorldObject.GetGroup() == null) continue;

                    Group group = insideWorldObject.GetGroup();
                    string groupId = group.GetId();

                    if (groupId != null && ItemsToHide.Contains(groupId))
                        continue;

                    if (group is GroupItem groupItem)
                    {
                        Group unlocksGroup = groupItem.GetUnlocksGroup();
                        if (unlocksGroup != null)
                        {
                            string unlocksId = unlocksGroup.GetId();
                            if (unlocksId != null && ItemsToHide.Contains(unlocksId))
                                continue;
                        }
                    }

                    if (group.GetGroupData() == groupBlueprint)
                    {
                        if (insideWorldObject.GetLinkedGroups() != null && insideWorldObject.GetLinkedGroups().Count > 0)
                        {
                            chipsInInventory.Insert(0, insideWorldObject);
                        }
                        else
                        {
                            chipsInInventory.Add(insideWorldObject);
                        }
                    }
                    else if (group is GroupItem groupItem2 && groupItem2.GetUnlocksGroup() != null)
                    {
                        chipsInInventory.Insert(0, insideWorldObject);
                    }
                }

                chipsField.SetValue(__instance, chipsInInventory);
                return false;
            }
            catch (Exception ex)
            {
                Plugin.Logger.LogError($"[Epoch] Error in PrefixSetSpecificChipsData: {ex.Message}");
                return true;
            }
        }

        // ============================================================
        // HARMONY PATCH: Hide items from UNLOCKED GROUPS display
        // ============================================================

        [HarmonyPatch(typeof(UnlockedGroupsHandler), "UnlockGroupGlobally")]
        [HarmonyPrefix]
        private static bool PrefixUnlockGroupGlobally(Group group, bool forceDisplayImmediate, bool showPopup)
        {
            if (group == null) return true;

            string groupId = group.GetId();

            if (groupId != null && ItemsToHide.Contains(groupId))
            {
                Plugin.Logger.LogDebug($"[Epoch] Blocked unlock attempt for hidden item: {groupId}");
                return false;
            }

            if (group is GroupItem groupItem)
            {
                Group unlocksGroup = groupItem.GetUnlocksGroup();
                if (unlocksGroup != null)
                {
                    string unlocksId = unlocksGroup.GetId();
                    if (unlocksId != null && ItemsToHide.Contains(unlocksId))
                    {
                        Plugin.Logger.LogDebug($"[Epoch] Blocked unlock attempt for blueprint that unlocks hidden item: {groupId} -> {unlocksId}");
                        return false;
                    }
                }
            }

            return true;
        }

        // ============================================================
        // HUB PLACEMENT RESTRICTION PATCHES
        // ============================================================

        [HarmonyPatch(typeof(PlayerBuilder), "InputOnAction")]
        [HarmonyPrefix]
        private static bool PrefixPlaceHub(PlayerBuilder __instance)
        {
            var ghostGroup = __instance.GetType().GetField("_ghostGroupConstructible",
                BindingFlags.NonPublic | BindingFlags.Instance)?.GetValue(__instance) as Group;

            if (ghostGroup == null || ghostGroup.GetId() != HubId)
                return true;

            if (HubExistsInWorld())
            {
                var hud = Managers.GetManager<BaseHudHandler>();
                if (hud != null)
                {
                    hud.DisplayCursorText(HubPlacementMessage, 3f);
                }
                else
                {
                    Plugin.Logger.LogWarning(HubPlacementMessage);
                }
                return false;
            }

            return true;
        }

        [HarmonyPatch(typeof(PlayerBuilder), "OnConstructed")]
        [HarmonyPostfix]
        private static void PostfixPlaceHub(PlayerBuilder __instance)
        {
            var constructedObjects = WorldObjectsHandler.Instance?.GetConstructedWorldObjects();
            if (constructedObjects == null)
                return;

            WorldObject latestHub = null;
            foreach (var wo in constructedObjects)
            {
                if (wo?.GetGroup()?.GetId() == HubId)
                {
                    if (latestHub == null || wo.GetId() > latestHub.GetId())
                        latestHub = wo;
                }
            }

            if (latestHub != null)
            {
                _activeHubId = latestHub.GetId();
                _hubWorldObjectId = latestHub.GetId();
                _currentTier = 1;
                IsRelocating = false;
                IsRecovering = false;
                CurrentRecoveryBudget = 50;
                RecoveryPercentage = 0f;

                Plugin.Logger.LogInfo($"[Epoch] Hub placed and registered. ID: {_activeHubId}, Tier: 1");

                if (EpochHubInventory != null)
                {
                    EpochVacuumSystem.Initialize(EpochHubInventory);
                }
            }
        }

        [HarmonyPatch(typeof(WorldObjectsHandler), "DestroyWorldObject", new Type[] { typeof(int), typeof(bool) })]
        [HarmonyPrefix]
        private static void PrefixDestroyHub(WorldObjectsHandler __instance, int woId, bool destroyGameObject)
        {
            if (woId == _activeHubId)
            {
                _activeHubId = -1;
                _hubWorldObjectId = -1;
                IsRelocating = false;
                IsRecovering = false;
                Plugin.Logger.LogInfo($"[Epoch] Hub destroyed. New hub can now be placed.");
            }
        }

        private static bool HubExistsInWorld()
        {
            if (_activeHubId != -1)
            {
                var wo = WorldObjectsHandler.Instance?.GetWorldObjectViaId(_activeHubId);
                if (wo != null && wo.GetGroup()?.GetId() == HubId)
                    return true;
                else
                    _activeHubId = -1;
            }

            var constructedObjects = WorldObjectsHandler.Instance?.GetConstructedWorldObjects();
            if (constructedObjects == null)
                return false;

            foreach (var wo in constructedObjects)
            {
                if (wo?.GetGroup()?.GetId() == HubId)
                {
                    _activeHubId = wo.GetId();
                    _hubWorldObjectId = wo.GetId();
                    return true;
                }
            }

            return false;
        }

        // ============================================================
        // HUB GHOST COLOR CHANGE
        // ============================================================

        [HarmonyPatch(typeof(ConstructibleGhost), "InitGhost")]
        [HarmonyPostfix]
        private static void PostfixInitGhost(ConstructibleGhost __instance, Group ghostGroupConstructible, PlayerAimController playerAimController, WorldObject wo, Action closeGhost)
        {
            if (ghostGroupConstructible == null || ghostGroupConstructible.GetId() != HubId)
                return;

            if (HubExistsInWorld())
            {
                ChangeGhostColor(__instance, Color.red);
                Plugin.Logger.LogInfo("[Epoch] Hub ghost set to RED - hub already exists.");
            }
            else
            {
                ChangeGhostColor(__instance, Color.white);
            }
        }

        private static void ChangeGhostColor(ConstructibleGhost ghost, Color color)
        {
            if (ghost == null)
                return;

            try
            {
                var renderers = ghost.GetComponentsInChildren<Renderer>(true);

                foreach (var renderer in renderers)
                {
                    if (renderer == null) continue;

                    Material[] newMaterials = new Material[renderer.materials.Length];
                    for (int i = 0; i < renderer.materials.Length; i++)
                    {
                        if (renderer.materials[i] == null) continue;

                        Material newMat = new Material(renderer.materials[i]);

                        if (newMat.HasProperty("_Color"))
                            newMat.SetColor("_Color", color);
                        if (newMat.HasProperty("_BaseColor"))
                            newMat.SetColor("_BaseColor", color);
                        if (newMat.HasProperty("_EmissionColor"))
                            newMat.SetColor("_EmissionColor", color * 0.3f);

                        if (newMat.shader != null)
                        {
                            int mainColorId = Shader.PropertyToID("_MainColor");
                            if (newMat.HasProperty(mainColorId))
                                newMat.SetColor(mainColorId, color);

                            int unlitColorId = Shader.PropertyToID("_UnlitColor");
                            if (newMat.HasProperty(unlitColorId))
                                newMat.SetColor(unlitColorId, color);

                            int glowColorId = Shader.PropertyToID("_GlowColor");
                            if (newMat.HasProperty(glowColorId))
                                newMat.SetColor(glowColorId, color);
                        }

                        newMaterials[i] = newMat;
                    }

                    renderer.materials = newMaterials;
                }

                var ghostRenderer = ghost.GetComponent<Renderer>();
                if (ghostRenderer != null && ghostRenderer.material != null)
                {
                    Material overrideMat = new Material(ghostRenderer.material);
                    if (overrideMat.HasProperty("_Color"))
                        overrideMat.SetColor("_Color", color);
                    else if (overrideMat.HasProperty("_BaseColor"))
                        overrideMat.SetColor("_BaseColor", color);
                    ghostRenderer.material = overrideMat;
                }
            }
            catch (Exception ex)
            {
                Plugin.Logger.LogWarning($"[Epoch] Could not change ghost color: {ex.Message}");
            }
        }

        // ============================================================
        // HUB REGISTRATION - STATIC COPIER PIPELINE
        // ============================================================
        private static void RegisterEpochHub()
        {
            try
            {
                List<Group> groups = GroupsHandler.GetAllGroups();
                if (groups == null || groups.Exists(g => g?.GetId() == HubId)) return;

                GroupConstructible container = GroupsHandler.GetGroupViaId("Container3") as GroupConstructible;
                GroupDataConstructible containerData = container?.GetGroupData() as GroupDataConstructible;
                if (containerData == null) return;

                GroupDataConstructible hubData = ScriptableObject.CreateInstance<GroupDataConstructible>();

                hubData.id = HubId;
                hubData.name = "Epoch Hub";
                hubData.icon = containerData.icon;
                hubData.inventorySize = HubInventorySize;
                hubData.secondaryInventoriesSize = new List<int> { 240, 240, 240, 240, 240, 240, 240, 240 };
                hubData.unlockingWorldUnit = DataConfig.WorldUnitType.Terraformation;
                hubData.unlockingValue = 0f;

                GroupConstructible epochHub = new GroupConstructible(hubData) { id = HubId };

                if (GroupAssociatedGameObjectField != null && container != null)
                {
                    // Safe access check to avoid early lifecycle lifecycle null reference errors
                    var modelPrefab = container.GetAssociatedGameObject();
                    if (modelPrefab != null)
                    {
                        GroupAssociatedGameObjectField.SetValue(epochHub, modelPrefab);
                    }
                }

                epochHub.SetRecipe(new Recipe(new List<GroupDataItem>()));
                GroupBackingIdField?.SetValue(epochHub, HubId);

                groups.Add(epochHub);
                GroupsHandler.SetAllGroups(groups);
                Plugin.Logger?.LogInfo($"[Epoch] Registered Hub cleanly.");
            }
            catch (Exception ex) { Plugin.Logger?.LogError($"[Epoch] Hub build failure: {ex.Message}"); }
        }

        // ============================================================
        // DRILL REGISTRATION - STATIC COPIER PIPELINE
        // ============================================================
        private static void RegisterEpochDrill()
        {
            try
            {
                List<Group> groups = GroupsHandler.GetAllGroups();
                if (groups == null || groups.Exists(g => g?.GetId() == DrillId)) return;

                GroupConstructible template = GroupsHandler.GetGroupViaId("OreExtractor3") as GroupConstructible;
                GroupDataConstructible templateData = template?.GetGroupData() as GroupDataConstructible;
                if (templateData == null) return;

                GroupDataConstructible drillData = ScriptableObject.CreateInstance<GroupDataConstructible>();

                drillData.id = DrillId;
                drillData.name = "Epoch Node Extractor";
                drillData.icon = templateData.icon;
                drillData.unlockingWorldUnit = DataConfig.WorldUnitType.Terraformation;
                drillData.unlockingValue = 0f;

                GroupConstructible epochDrill = new GroupConstructible(drillData) { id = DrillId };

                if (GroupAssociatedGameObjectField != null && template != null)
                {
                    // Safe access check to avoid early lifecycle lifecycle null reference errors
                    var modelPrefab = template.GetAssociatedGameObject();
                    if (modelPrefab != null)
                    {
                        GroupAssociatedGameObjectField.SetValue(epochDrill, modelPrefab);
                    }
                }

                epochDrill.SetRecipe(new Recipe(new List<GroupDataItem>()));
                GroupBackingIdField?.SetValue(epochDrill, DrillId);

                groups.Add(epochDrill);
                GroupsHandler.SetAllGroups(groups);
                Plugin.Logger?.LogInfo($"[Epoch] Registered Drill cleanly.");
            }
            catch (Exception ex) { Plugin.Logger?.LogError($"[Epoch] Drill build failure: {ex.Message}"); }
        }




        // ============================================================
        // LOCALIZATION
        // ============================================================

        private static void RegisterLocalization()
        {
            AddLocalization("GROUP_NAME_Epoch_Hub", "Epoch Hub");
            AddLocalization("GROUP_DESC_Epoch_Hub", "Stores every obtainable resource. Tier-based upgrades!");

            AddLocalization("GROUP_NAME_Epoch_Node_Drill", "Epoch Node Extractor");
            AddLocalization("GROUP_DESC_Epoch_Node_Drill", "Transmits automated regional extraction telemetry back to the base hub.");
        }

        private static void AddLocalization(string key, string value)
        {
            try
            {
                var dictionary = LocalizationDictionaryField?.GetValue(null) as Dictionary<string, Dictionary<string, string>>;
                if (dictionary == null) return;

                foreach (var language in dictionary.Values)
                {
                    language[key] = value;
                }
            }
            catch { }
        }
    }
}