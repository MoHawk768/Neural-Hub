﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using SpaceCraft;

namespace EpochNeural
{
    public partial class EpochDevHud : MonoBehaviour
    {
        public static EpochDevHud Instance { get; private set; }

        private GameObject _hudCanvasObject;
        private Canvas _hudCanvas;
        private GameObject _panelObject;

        private TextMeshProUGUI _txtHeader;
        private TextMeshProUGUI _txtDiscovery;
        private TextMeshProUGUI _txtDrills;
        private TextMeshProUGUI _txtLeft;
        private TextMeshProUGUI _txtCount;

        private string _txtDiscoveryContent = "Biome Resource Discovered: 0 / 0";
        private string _txtDrillsContent = "Active Node Drill Link   : 0 / 12";
        private string _txtLeftContent = "Biome Resources Left : 0";
        private string _txtCountContent = "Hub Item Count       : 0";
        private bool _isVisible = true;
        private int _planetMaxDrillGoal = 12;

        private readonly HashSet<string> _permanentlyScannedOres = new HashSet<string>();
        private readonly HashSet<string> _occupiedBiomesRegistry = new HashSet<string>();

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(this.gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(this.gameObject);
        }

        private void Start()
        {
            StartCoroutine(InitializeHudRoutine());
        }

        private IEnumerator InitializeHudRoutine()
        {
            yield return new WaitForSeconds(3.0f);
            try
            {
                string sceneName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
                if (sceneName.Contains("Humble") || sceneName.Contains("Toxicity")) _planetMaxDrillGoal = 8;
                else if (sceneName.Contains("Selenea") || sceneName.Contains("Moon") || sceneName.Contains("Aqualis")) _planetMaxDrillGoal = 7;
                else _planetMaxDrillGoal = 12;

                _hudCanvasObject = new GameObject("EpochDevHudCanvas");
                DontDestroyOnLoad(_hudCanvasObject);
                _hudCanvas = _hudCanvasObject.AddComponent<Canvas>();
                _hudCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                _hudCanvas.sortingOrder = 999;

                CanvasScaler scaler = _hudCanvasObject.AddComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(1920, 1080);

                _panelObject = new GameObject("HudPanel");
                _panelObject.transform.SetParent(_hudCanvasObject.transform, false);
                RectTransform rect = _panelObject.AddComponent<RectTransform>();
                rect.anchorMin = new Vector2(0, 1); rect.anchorMax = new Vector2(0, 1); rect.pivot = new Vector2(0, 1);
                rect.anchoredPosition = new Vector2(20, -20); rect.sizeDelta = new Vector2(400, 195);

                _panelObject.AddComponent<Image>().color = new Color(0f, 0f, 0f, 0.65f);

                _txtHeader = CreateGenericTextObject("Line1", new Vector2(15, -15), 16, Color.cyan);
                _txtHeader.text = "Epoch Neural Network"; _txtHeader.fontStyle = FontStyles.Bold;

                _txtDiscovery = CreateGenericTextObject("Line2", new Vector2(15, -50), 14, new Color(0.3f, 0.75f, 1f));
                _txtDrills = CreateGenericTextObject("Line3", new Vector2(15, -80), 14, Color.yellow);
                _txtLeft = CreateGenericTextObject("Line4", new Vector2(15, -110), 14, Color.white);
                _txtCount = CreateGenericTextObject("Line5", new Vector2(15, -140), 14, Color.green);

                if (_panelObject != null) _panelObject.SetActive(false);
                StartCoroutine(UpdateHudLoop());
            }
            catch { }
        }

        private TextMeshProUGUI CreateGenericTextObject(string name, Vector2 anchoredPosition, int size, Color c)
        {
            GameObject textObj = new GameObject(name);
            textObj.transform.SetParent(_panelObject.transform, false);
            RectTransform rect = textObj.AddComponent<RectTransform>();
            rect.anchorMin = new Vector2(0, 1); rect.anchorMax = new Vector2(1, 1); rect.pivot = new Vector2(0, 1);
            rect.anchoredPosition = anchoredPosition; rect.sizeDelta = new Vector2(-30, 30);

            TextMeshProUGUI tmp = textObj.AddComponent<TextMeshProUGUI>();
            TMP_FontAsset fontAsset = FontAssetHelper.GetDefaultFont();
            if (fontAsset != null) tmp.font = fontAsset;
            tmp.fontSize = size; tmp.color = c; tmp.alignment = TextAlignmentOptions.TopLeft; tmp.text = "...";
            return tmp;
        }

        private IEnumerator UpdateHudLoop()
        {
            while (true)
            {
                if (_isVisible && _panelObject != null && _panelObject.activeSelf)
                {
                    if (_txtDiscovery != null) _txtDiscovery.text = _txtDiscoveryContent;
                    if (_txtDrills != null) _txtDrills.text = _txtDrillsContent;
                    if (_txtLeft != null) _txtLeft.text = _txtLeftContent;
                    if (_txtCount != null) _txtCount.text = _txtCountContent;
                }
                yield return new WaitForSeconds(0.2f);
            }
        }
    }
}
namespace EpochNeural
{
    public partial class EpochDevHud
    {
        public void UpdateHud(bool hubActive, int worldObjects, int containerItemCount)
        {
            int localAvailable = 0; int localLearned = 0; int placedDrillsCount = 0;
            _occupiedBiomesRegistry.Clear();

            try
            {
                Type sectorsType = Type.GetType("SpaceCraft.SectorsHandler, Assembly-CSharp");
                object sectorsHandler = sectorsType != null ? UnityEngine.Object.FindFirstObjectByType(sectorsType) : null;

                var worldObjectsList = WorldObjectsHandler.Instance?.GetConstructedWorldObjects();
                if (worldObjectsList != null && sectorsHandler != null)
                {
                    foreach (WorldObject wo in worldObjectsList)
                    {
                        if (wo == null || wo.GetGroup() == null || wo.GetGroup().GetId() != "Epoch_Node_Drill")
                            continue;

                        string sectorGroupId = "UnknownBiome";
                        try
                        {
                            var sector = sectorsHandler.GetType().GetMethod("GetSectorWithPosition")?.Invoke(sectorsHandler, new object[] { wo.GetPosition() });
                            if (sector != null)
                            {
                                sectorGroupId = sector.GetType().GetMethod("GetGroupId")?.Invoke(sector, null) as string;
                            }
                        }
                        catch { }

                        if (_occupiedBiomesRegistry.Contains(sectorGroupId) && sectorGroupId != "UnknownBiome")
                        {
                            Managers.GetManager<BaseHudHandler>()?.DisplayCursorText("EPOCH: Link Already Established In This Biome!", 3f);
                            WorldObjectsHandler.Instance.DestroyWorldObject(wo.GetId());
                            continue;
                        }

                        _occupiedBiomesRegistry.Add(sectorGroupId);
                        placedDrillsCount++;
                    }
                }

                var discovery = EpochVacuumDiscovery.DiscoverCollectibles();
                if (discovery != null && discovery.Objects != null && EpochNeural.EpochHubInventory != null)
                {
                    var hubItems = EpochNeural.EpochHubInventory.GetInsideWorldObjects();
                    foreach (WorldObject wo in discovery.Objects)
                    {
                        if (wo?.GetGroup() is GroupItem) _permanentlyScannedOres.Add(wo.GetGroup().GetId());
                    }

                    if (hubItems != null)
                    {
                        foreach (WorldObject wo in hubItems)
                        {
                            if (wo?.GetGroup() is GroupItem) _permanentlyScannedOres.Add(wo.GetGroup().GetId());
                        }
                    }

                    localAvailable = _permanentlyScannedOres.Count;

                    foreach (string id in _permanentlyScannedOres)
                    {
                        if (hubItems == null) continue;
                        foreach (WorldObject wo in hubItems)
                        {
                            if (wo?.GetGroup() != null && wo.GetGroup().GetId() == id) { localLearned++; break; }
                        }
                    }
                }
            }
            catch { }

            UpdateHudData(hubActive, worldObjects, containerItemCount, localLearned, localAvailable, placedDrillsCount);
        }

        public void UpdateHudData(bool active, int left, int count, int learned, int available, int activeDrills)
        {
            if (_panelObject != null && _panelObject.activeSelf != active) _panelObject.SetActive(active);
            _txtDiscoveryContent = $"Biome Resource Discovered: {learned} / {available}";
            _txtDrillsContent = $"Active Node Drill Link   : {activeDrills} / {_planetMaxDrillGoal}";
            _txtLeftContent = $"Biome Resources Left : {left:N0}";
            _txtCountContent = $"Hub Item Count       : {count:N0}";
        }

        public void ToggleVisibility()
        {
            _isVisible = !_isVisible;
            if (_panelObject != null) _panelObject.SetActive(_isVisible);
        }
    }

    public static class FontAssetHelper
    {
        private static TMPro.TMP_FontAsset _cachedFont;
        public static TMPro.TMP_FontAsset GetDefaultFont()
        {
            if (_cachedFont != null) return _cachedFont;
            try
            {
                TMPro.TMP_FontAsset[] loadedFonts = UnityEngine.Resources.FindObjectsOfTypeAll<TMPro.TMP_FontAsset>();
                if (loadedFonts != null && loadedFonts.Length > 0) { _cachedFont = loadedFonts[0]; return _cachedFont; }
            }
            catch { }
            return TMPro.TMP_Settings.defaultFontAsset;
        }
    }
}
